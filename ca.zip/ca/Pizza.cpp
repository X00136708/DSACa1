//x00136708 Ronan Doran
#include <iostream>
#include <fstream>
void readFile();
void calc(char[10], int, int, int);
void print(int);
using namespace std;
static int totalPizzas = 0;

int main() {

	readFile();

}
void readFile() {
	ifstream myFile;
	myFile.open("Pizza.txt");
	char name[10];
	int type, quantity;
	int totalLines = 1;
	char cust[50];
	int counter = 0;
	if (myFile.is_open()) {
		while (!myFile.eof()) {
			myFile >> name >> type >> quantity;
			cout << name << " " << type << " " << quantity << endl;
			calc(name, type, quantity, totalLines, cust, counter);
			totalLines++;
		}
	}
	myFile.close();


}
void calc(char name[10], int type, int quantity, int totalLines, char cust[], int counter) {
	
	cust[counter] = name;
	counter++;
	totalPizzas += quantity;


	if (totalLines == 10) {
		print(totalLines);
	}
	

}
void print(int totalLines) {
	double average = totalPizzas / totalLines;
	cout << endl << "Total pizzas: " << totalPizzas << endl;
	cout << "Total customers: " << totalLines << endl;
	cout << "Average quantity: " << average << endl;
	//cout << customerMost << " ordered the most pizza" << endl
	system("PAUSE");
}