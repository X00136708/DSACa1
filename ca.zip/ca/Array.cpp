#include <iostream>
using namespace std;
void fillArray();
void showArray(int[], int);
void reverseArray(int[], int, int);
void findMode(int[], int);
int main() {
	fillArray();
}
void fillArray() {
	char name[20];
	int numbers[10];
	int size;
	int counter = 0;
	cout << "Enter the name and size of the array:  ";
	cin >> name >> size;
	cout << "Name of the array: " << name << endl;
	cout << "Size: " << size << endl;
	
	do {
		cout << "Enter value " << counter << endl;
		cin >> numbers[counter];
		counter++;

	} while (counter < size);
	cout << "Number of entries: " << counter << endl;
	showArray(numbers, counter);
	reverseArray(numbers, counter, size);
	
}
void showArray(int numbers[20], int counter) {
	for (int i = 0; i < counter; i++) {
		cout << "Array @ position " << i << " is " << numbers[i] << endl;
	}
	findMode(numbers, counter);
	
}
void reverseArray(int numbers[20], int counter, int size) {
	for (int i = 0, j = size -1; i < size, j > 0; i++, j--) {
		int temp = numbers[i];
		numbers[i] = numbers[j];
		numbers[j] = temp;
	}
	cout << endl;
	for (int i = 0; i < counter; i++) {
		cout << "Reversed array: " << numbers[i] << endl;
	}
}
void findMode(int numbers[10], int counter) {
	int most = 0;
	int num = 0;
	for (int i = 0; i < counter; i++) {
		for (int j = i+1; j < counter; j++) {
			
				if (numbers[i] == numbers[j]) {
					most = numbers[j];
					num++;
				}
			
		}
	}
	if (most != 0) {
		cout << most << " appears: " << num << " times." << endl;
		//only problem with this is that if there is 3 elements in the array and 2 are 1's, 
		//the code only picks up that it appeared once. This is only the case for 3 elements, any more and it works fine
	}
	else {
		cout << "There is no mode as no numbers match" << endl;
	}
	

}